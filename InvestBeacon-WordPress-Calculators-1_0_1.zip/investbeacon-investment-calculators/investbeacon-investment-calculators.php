<?php
/**
 * Plugin Name: InvestBeacon Investment Calculators
 * Description: Add compound growth, ongoing fee impact and inflation calculators using a block or shortcode. Calculations stay in the visitor's browser.
 * Version: 1.0.1
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Author: InvestBeacon
 * Author URI: https://investbeacon.eu/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: investbeacon-investment-calculators
 */

namespace InvestBeacon\InvestmentCalculators;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const VERSION = '1.0.1';
const DOMAIN = 'investbeacon-investment-calculators';

function register_assets() {
    $url = plugin_dir_url( __FILE__ );
    wp_register_style( 'investbeacon-calculators', $url . 'assets/calculators.css', array(), VERSION );
    wp_register_script( 'investbeacon-calculators-math', $url . 'assets/math.js', array(), VERSION, true );
    wp_register_script( 'investbeacon-calculators-ui', $url . 'assets/calculators.js', array( 'investbeacon-calculators-math' ), VERSION, true );
    wp_register_script( 'investbeacon-calculators-editor', $url . 'assets/editor.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n' ), VERSION, true );
    wp_set_script_translations( 'investbeacon-calculators-editor', DOMAIN );
    register_block_type( __DIR__ . '/block', array( 'render_callback' => __NAMESPACE__ . '\render_block' ) );
}
add_action( 'init', __NAMESPACE__ . '\register_assets' );

// A small scoped stylesheet is loaded on front-end pages so shortcodes also work in
// widgets/templates rendered after wp_head. Calculation scripts load only on use.
function enqueue_styles() {
    wp_enqueue_style( 'investbeacon-calculators' );
}
add_action( 'wp_enqueue_scripts', __NAMESPACE__ . '\enqueue_styles' );

function normalized_attributes( $raw ) {
    $raw = is_array( $raw ) ? $raw : array();
    $defaults = array( 'type' => 'all', 'initial' => 5000, 'monthly' => 250, 'years' => 20, 'rate' => 6, 'fee' => 0.2, 'inflation' => 2, 'currency' => 'EUR', 'timing' => 'end', 'credit' => false );
    $bounds = array( 'initial' => array( 0, 100000000 ), 'monthly' => array( 0, 1000000 ), 'years' => array( 1, 60 ), 'rate' => array( -50, 50 ), 'fee' => array( 0, 10 ), 'inflation' => array( -10, 30 ) );
    $result = $defaults;
    foreach ( $bounds as $name => $range ) {
        if ( isset( $raw[ $name ] ) && is_scalar( $raw[ $name ] ) && is_numeric( $raw[ $name ] ) ) {
            $number = (float) $raw[ $name ];
            if ( is_finite( $number ) ) {
                $result[ $name ] = max( $range[0], min( $range[1], $number ) );
            }
        }
    }
    foreach ( $bounds as $name => $range ) {
        $result[ $name ] = round( $result[ $name ], 'years' === $name ? 0 : 2 );
    }
    $result['years'] = (int) $result['years'];
    foreach ( array( 'type' => array( 'all', 'compound', 'fees', 'inflation' ), 'currency' => array( 'EUR', 'GBP', 'USD', 'CHF', 'PLN', 'SEK', 'DKK', 'NOK', 'CZK', 'HUF', 'RON' ), 'timing' => array( 'end', 'beginning' ) ) as $name => $allowed ) {
        if ( isset( $raw[ $name ] ) && in_array( $raw[ $name ], $allowed, true ) ) {
            $result[ $name ] = $raw[ $name ];
        }
    }
    $result['credit'] = isset( $raw['credit'] ) && in_array( $raw['credit'], array( true, 'true', '1', 1 ), true );
    return $result;
}

function labels() {
    return array(
        'compound' => __( 'Compound growth', 'investbeacon-investment-calculators' ),
        'fees' => __( 'Impact of fees', 'investbeacon-investment-calculators' ),
        'inflation' => __( 'Purchasing power', 'investbeacon-investment-calculators' ),
        'estimatedValue' => __( 'Estimated final value', 'investbeacon-investment-calculators' ),
        'contributed' => __( 'Total contributed', 'investbeacon-investment-calculators' ),
        'gain' => __( 'Estimated gain or loss', 'investbeacon-investment-calculators' ),
        'withoutFees' => __( 'Without ongoing fees', 'investbeacon-investment-calculators' ),
        'feeImpact' => __( 'Impact on final value', 'investbeacon-investment-calculators' ),
        'directFees' => __( 'Direct ongoing charges', 'investbeacon-investment-calculators' ),
        'realValue' => __( 'In today’s money', 'investbeacon-investment-calculators' ),
        'nominalValue' => __( 'Nominal value', 'investbeacon-investment-calculators' ),
        'realRate' => __( 'Real annual return after fees', 'investbeacon-investment-calculators' ),
        'year' => __( 'Year', 'investbeacon-investment-calculators' ),
        'chart' => __( 'Estimated values over time. The annual table contains the same data.', 'investbeacon-investment-calculators' ),
        'invalid' => __( 'Check the highlighted inputs. Results are hidden until all values are valid.', 'investbeacon-investment-calculators' ),
        'updated' => __( 'Estimates updated.', 'investbeacon-investment-calculators' ),
        'compoundNote' => __( 'Estimated gain or loss is final value minus your contributions. It can be negative.', 'investbeacon-investment-calculators' ),
        'feesNote' => __( 'Impact on final value compares the same scenario with and without ongoing fees. It includes direct charges and the effect on compounding; it is not just a bill for fees paid.', 'investbeacon-investment-calculators' ),
        'inflationNote' => __( 'Today’s-money values discount the final balance for inflation. Contributions stay fixed in nominal terms; their future purchasing power is not fixed.', 'investbeacon-investment-calculators' ),
    );
}

function render_calculator( $attributes ) {
    $a = normalized_attributes( $attributes );
    $id = wp_unique_id( 'ibcalc-' );
    $strings = labels();
    wp_enqueue_script( 'investbeacon-calculators-ui' );
    $field = static function ( $key, $label, $min, $max, $step, $suffix = '' ) use ( $a, $id ) {
        ?>
        <div class="ibcalc-field">
            <label for="<?php echo esc_attr( $id . '-' . $key ); ?>"><?php echo esc_html( $label ); ?><?php if ( $suffix ) : ?> <span><?php echo esc_html( $suffix ); ?></span><?php endif; ?></label>
            <input id="<?php echo esc_attr( $id . '-' . $key ); ?>" data-field="<?php echo esc_attr( $key ); ?>" type="number" inputmode="decimal" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>" step="<?php echo esc_attr( $step ); ?>" value="<?php echo esc_attr( $a[ $key ] ); ?>" required>
        </div>
        <?php
    };
    ob_start();
    ?>
    <section class="ibcalc" data-ibcalc data-config="<?php echo esc_attr( wp_json_encode( $a ) ); ?>" data-labels="<?php echo esc_attr( wp_json_encode( $strings ) ); ?>" aria-labelledby="<?php echo esc_attr( $id . '-title' ); ?>">
        <header class="ibcalc-header"><p class="ibcalc-eyebrow"><?php esc_html_e( 'Plan with clear assumptions', 'investbeacon-investment-calculators' ); ?></p><h2 id="<?php echo esc_attr( $id . '-title' ); ?>"><?php esc_html_e( 'See what time can change.', 'investbeacon-investment-calculators' ); ?></h2><p><?php esc_html_e( 'Explore growth, ongoing fees and the purchasing power of your savings.', 'investbeacon-investment-calculators' ); ?></p></header>
        <div class="ibcalc-layout">
            <div class="ibcalc-inputs" role="group" aria-label="<?php esc_attr_e( 'Your assumptions', 'investbeacon-investment-calculators' ); ?>">
                <div class="ibcalc-field"><label for="<?php echo esc_attr( $id . '-mode' ); ?>"><?php esc_html_e( 'Calculator', 'investbeacon-investment-calculators' ); ?></label><select id="<?php echo esc_attr( $id . '-mode' ); ?>" data-field="mode" <?php disabled( 'all' !== $a['type'] ); ?>><?php foreach ( array( 'compound', 'fees', 'inflation' ) as $mode ) : ?><option value="<?php echo esc_attr( $mode ); ?>" <?php selected( 'all' === $a['type'] ? 'compound' : $a['type'], $mode ); ?>><?php echo esc_html( $strings[ $mode ] ); ?></option><?php endforeach; ?></select></div>
                <div class="ibcalc-input-grid">
                    <?php $field( 'initial', __( 'Initial investment', 'investbeacon-investment-calculators' ), 0, 100000000, '0.01' ); ?>
                    <?php $field( 'monthly', __( 'Monthly contribution', 'investbeacon-investment-calculators' ), 0, 1000000, '0.01' ); ?>
                    <?php $field( 'years', __( 'Time horizon', 'investbeacon-investment-calculators' ), 1, 60, 1, __( 'years', 'investbeacon-investment-calculators' ) ); ?>
                    <?php $field( 'rate', __( 'Annual gross return', 'investbeacon-investment-calculators' ), -50, 50, '0.01', '%' ); ?>
                    <?php $field( 'fee', __( 'Annual ongoing fee', 'investbeacon-investment-calculators' ), 0, 10, '0.01', '%' ); ?>
                    <?php $field( 'inflation', __( 'Annual inflation', 'investbeacon-investment-calculators' ), -10, 30, '0.01', '%' ); ?>
                    <div class="ibcalc-field"><label for="<?php echo esc_attr( $id . '-currency' ); ?>"><?php esc_html_e( 'Display currency', 'investbeacon-investment-calculators' ); ?></label><select id="<?php echo esc_attr( $id . '-currency' ); ?>" data-field="currency"><?php foreach ( array( 'EUR', 'GBP', 'USD', 'CHF', 'PLN', 'SEK', 'DKK', 'NOK', 'CZK', 'HUF', 'RON' ) as $currency ) : ?><option <?php selected( $a['currency'], $currency ); ?>><?php echo esc_html( $currency ); ?></option><?php endforeach; ?></select></div>
                    <div class="ibcalc-field"><label for="<?php echo esc_attr( $id . '-timing' ); ?>"><?php esc_html_e( 'Contributions arrive', 'investbeacon-investment-calculators' ); ?></label><select id="<?php echo esc_attr( $id . '-timing' ); ?>" data-field="timing"><option value="end" <?php selected( $a['timing'], 'end' ); ?>><?php esc_html_e( 'End of each month', 'investbeacon-investment-calculators' ); ?></option><option value="beginning" <?php selected( $a['timing'], 'beginning' ); ?>><?php esc_html_e( 'Beginning of each month', 'investbeacon-investment-calculators' ); ?></option></select></div>
                </div>
                <div class="ibcalc-actions"><button type="button" data-action="calculate"><?php esc_html_e( 'Calculate', 'investbeacon-investment-calculators' ); ?></button><button type="button" class="ibcalc-secondary" data-action="reset"><?php esc_html_e( 'Reset', 'investbeacon-investment-calculators' ); ?></button></div>
                <p class="ibcalc-local"><?php esc_html_e( 'Calculations run in this browser. Nothing you enter is sent by this calculator.', 'investbeacon-investment-calculators' ); ?></p>
            </div>
            <div class="ibcalc-output"><p class="ibcalc-status" data-status role="status" aria-live="polite"></p><div data-results>
                <div class="ibcalc-result-primary"><p data-primary-label></p><strong data-primary-value></strong><span data-result-context></span></div>
                <dl class="ibcalc-metrics" data-metrics></dl>
                <div class="ibcalc-chart" data-chart></div><ul class="ibcalc-legend" data-legend></ul>
                <p class="ibcalc-result-note" data-note></p>
                <details class="ibcalc-table-details"><summary><?php esc_html_e( 'View annual breakdown', 'investbeacon-investment-calculators' ); ?></summary><div class="ibcalc-table-scroll" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Annual estimates', 'investbeacon-investment-calculators' ); ?>"><table><caption class="ibcalc-screen-reader"><?php esc_html_e( 'Estimated end-of-year values', 'investbeacon-investment-calculators' ); ?></caption><thead data-table-head></thead><tbody data-table-body></tbody></table></div></details>
                <button type="button" class="ibcalc-download" data-action="download"><?php esc_html_e( 'Download annual figures (CSV)', 'investbeacon-investment-calculators' ); ?></button>
            </div></div>
        </div>
        <details class="ibcalc-method"><summary><?php esc_html_e( 'How these estimates work', 'investbeacon-investment-calculators' ); ?></summary><p><?php esc_html_e( 'The model converts your effective annual return and annual ongoing fee to equivalent monthly factors. Each month it adds beginning-of-month contributions, applies growth, deducts the ongoing charge, then adds end-of-month contributions. Only your selected contribution timing is used. No intermediate rounding is applied.', 'investbeacon-investment-calculators' ); ?></p><p><?php esc_html_e( 'Inflation-adjusted values divide each year-end balance by the accumulated inflation factor. The annual ongoing fee is a percentage of the portfolio, not a flat transaction fee. Taxes, dealing commissions, FX charges, cash withdrawals and changes in returns or inflation are not included. Currency changes the display unit only; no exchange-rate conversion occurs.', 'investbeacon-investment-calculators' ); ?></p></details>
        <p class="ibcalc-disclaimer"><?php esc_html_e( 'Illustrative estimates, not forecasts or investment advice. Actual returns vary and losses are possible.', 'investbeacon-investment-calculators' ); ?></p>
        <?php if ( $a['credit'] ) : ?><p class="ibcalc-credit"><a href="https://investbeacon.eu/" target="_blank" rel="nofollow noopener noreferrer"><img src="<?php echo esc_url( plugin_dir_url( __FILE__ ) . 'assets/beacon.png' ); ?>" alt="" width="22" height="22"><?php esc_html_e( 'Calculator by InvestBeacon', 'investbeacon-investment-calculators' ); ?></a></p><?php endif; ?>
        <noscript><p><?php esc_html_e( 'Enable JavaScript in your browser to calculate these estimates.', 'investbeacon-investment-calculators' ); ?></p></noscript>
    </section>
    <?php
    return ob_get_clean();
}

function render_block( $attributes ) {
    return render_calculator( $attributes );
}

function shortcode( $attributes, $content = null, $tag = 'investbeacon_calculator' ) {
    $attributes = is_array( $attributes ) ? $attributes : array();
    $types = array( 'investbeacon_compound_interest' => 'compound', 'investbeacon_fee_impact' => 'fees', 'investbeacon_inflation' => 'inflation' );
    if ( isset( $types[ $tag ] ) ) {
        $attributes['type'] = $types[ $tag ];
    }
    return render_calculator( $attributes );
}
foreach ( array( 'investbeacon_calculator', 'investbeacon_compound_interest', 'investbeacon_fee_impact', 'investbeacon_inflation' ) as $investbeacon_shortcode_name ) {
    add_shortcode( $investbeacon_shortcode_name, __NAMESPACE__ . '\shortcode' );
}
unset( $investbeacon_shortcode_name );

function admin_menu() {
    add_management_page( __( 'InvestBeacon Calculators', 'investbeacon-investment-calculators' ), __( 'InvestBeacon Calculators', 'investbeacon-investment-calculators' ), 'manage_options', 'investbeacon-calculators', __NAMESPACE__ . '\help_page' );
}
add_action( 'admin_menu', __NAMESPACE__ . '\admin_menu' );

function help_page() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    ?>
    <div class="wrap"><h1><?php esc_html_e( 'InvestBeacon Investment Calculators', 'investbeacon-investment-calculators' ); ?></h1><p><?php esc_html_e( 'Add the Investment Calculator block to a page or paste a shortcode into a Shortcode block.', 'investbeacon-investment-calculators' ); ?></p><pre>[investbeacon_calculator]
[investbeacon_compound_interest]
[investbeacon_fee_impact]
[investbeacon_inflation]
[investbeacon_calculator initial="10000" monthly="300" years="25" rate="6" fee="0.2" inflation="2" currency="EUR" timing="end"]</pre><h2><?php esc_html_e( 'Optional credit', 'investbeacon-investment-calculators' ); ?></h2><p><?php esc_html_e( 'No credit or external link is shown to visitors by default. Enable the block’s credit toggle or add credit="true" to the shortcode if you want to display the InvestBeacon credit link.', 'investbeacon-investment-calculators' ); ?></p><h2><?php esc_html_e( 'Privacy', 'investbeacon-investment-calculators' ); ?></h2><p><?php esc_html_e( 'This plugin sends no calculation inputs to a server, stores no visitor inputs, creates no cookies and includes no analytics, remote fonts, remote scripts or external API calls. Your site and other plugins may have separate data practices.', 'investbeacon-investment-calculators' ); ?></p><p><a href="https://investbeacon.eu/" target="_blank" rel="noopener noreferrer">InvestBeacon</a> · <a href="https://investbeacon.eu/en/contact" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Support', 'investbeacon-investment-calculators' ); ?></a></p></div>
    <?php
}
