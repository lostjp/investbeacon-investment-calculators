/* InvestBeacon Investment Calculators. GPL-2.0-or-later. */
(function () {
  'use strict';
  const math = globalThis.InvestBeaconCalculatorsMath;
  if (!math) return;
  const initialized = new WeakSet();
  const colors = { nominal: '#173b67', contributed: '#8594a9', withoutFees: '#137b72', real: '#137b72' };

  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  function svgElement(tag, attrs, text) {
    const node = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function initialize(root) {
    if (initialized.has(root)) return;
    initialized.add(root);
    const fields = Object.fromEntries(Array.from(root.querySelectorAll('[data-field]'), node => [node.dataset.field, node]));
    const find = selector => root.querySelector(selector);
    let config;
    let labels;
    try { config = JSON.parse(root.dataset.config); labels = JSON.parse(root.dataset.labels); } catch { return; }
    const label = key => typeof labels[key] === 'string' ? labels[key] : key;
    const initial = { ...math.defaults, ...config };
    const locale = document.documentElement.lang.replace('_', '-') || 'en';
    let result = null;
    let timer;
    let formatter;
    function currency(value) { return formatter.format(value); }
    function columns(mode) {
      if (mode === 'fees') return [['nominal', 'estimatedValue'], ['withoutFees', 'withoutFees']];
      if (mode === 'inflation') return [['nominal', 'nominalValue'], ['real', 'realValue']];
      return [['contributed', 'contributed'], ['nominal', 'estimatedValue']];
    }

    function drawChart(mode) {
      const selected = columns(mode);
      const rows = result.yearly;
      const max = Math.max(1, ...rows.flatMap(row => selected.map(([key]) => row[key])));
      const svg = svgElement('svg', { viewBox: '0 0 500 210', role: 'img', 'aria-label': label('chart') });
      svg.append(svgElement('title', {}, label('chart')));
      const x = year => 70 + year / result.inputs.years * 412;
      const y = value => 178 - value / max * 150;
      const compact = new Intl.NumberFormat(locale, { notation: 'compact', maximumFractionDigits: 1 });
      for (const fraction of [0, 0.5, 1]) {
        const value = max * fraction;
        svg.append(svgElement('line', { x1: 70, x2: 482, y1: y(value), y2: y(value), stroke: '#dce5ef', 'stroke-dasharray': '3 5' }));
        svg.append(svgElement('text', { x: 59, y: y(value) + 4, 'text-anchor': 'end', fill: '#5d6c82', 'font-size': 12 }, compact.format(value)));
      }
      for (const [key] of selected) {
        svg.append(svgElement('polyline', { points: rows.map(row => x(row.year) + ',' + y(row[key])).join(' '), fill: 'none', stroke: colors[key], 'stroke-width': 3, 'stroke-linejoin': 'round', 'stroke-dasharray': key === 'contributed' || key === 'withoutFees' ? '6 4' : 'none' }));
      }
      svg.append(svgElement('text', { x: 70, y: 204, fill: '#5d6c82', 'font-size': 12 }, label('year') + ' 0'));
      svg.append(svgElement('text', { x: 482, y: 204, 'text-anchor': 'end', fill: '#5d6c82', 'font-size': 12 }, label('year') + ' ' + result.inputs.years));
      find('[data-chart]').replaceChildren(svg);
      const legend = find('[data-legend]');
      legend.replaceChildren();
      for (const [key, text] of selected) {
        const item = element('li', label(text));
        item.style.setProperty('--ibcalc-series', colors[key]);
        legend.append(item);
      }
    }

    function render(mode) {
      const metrics = mode === 'fees'
        ? [['withoutFees', result.withoutFees], ['feeImpact', result.feeImpact], ['directFees', result.directFees]]
        : mode === 'inflation'
          ? [['nominalValue', result.nominal], ['contributed', result.contributed], ['realRate', result.realAnnualRate]]
          : [['contributed', result.contributed], ['gain', result.gain]];
      find('[data-primary-label]').textContent = label(mode === 'inflation' ? 'realValue' : 'estimatedValue');
      find('[data-primary-value]').textContent = currency(mode === 'inflation' ? result.real : result.nominal);
      find('[data-result-context]').textContent = label('year') + ' ' + result.inputs.years + ' · ' + result.inputs.currency;
      const list = find('[data-metrics]');
      list.replaceChildren();
      for (const [key, value] of metrics) {
        const item = element('div');
        item.append(element('dt', label(key)), element('dd', key === 'realRate' ? new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(value) + '%' : currency(value)));
        if (key === 'gain' && value < 0) item.className = 'ibcalc-negative';
        list.append(item);
      }
      find('[data-note]').textContent = label(mode + 'Note');
      const selected = columns(mode);
      const headingRow = element('tr');
      for (const text of [label('year'), label('contributed'), ...selected.filter(([key]) => key !== 'contributed').map(([, key]) => label(key))]) {
        const header = element('th', text); header.scope = 'col'; headingRow.append(header);
      }
      find('[data-table-head]').replaceChildren(headingRow);
      const body = document.createDocumentFragment();
      for (const row of result.yearly) {
        const tr = element('tr');
        const year = element('th', String(row.year)); year.scope = 'row'; tr.append(year, element('td', currency(row.contributed)));
        for (const [key] of selected.filter(([key]) => key !== 'contributed')) tr.append(element('td', currency(row[key])));
        body.append(tr);
      }
      find('[data-table-body]').replaceChildren(body);
      drawChart(mode);
    }

    function update(report) {
      clearTimeout(timer);
      let invalid = null;
      for (const input of Object.values(fields)) {
        const valid = input.disabled || input.checkValidity();
        input.setAttribute('aria-invalid', valid ? 'false' : 'true');
        if (!valid && !invalid) invalid = input;
      }
      const status = find('[data-status]');
      if (invalid) {
        result = null; find('[data-results]').hidden = true;
        status.textContent = label('invalid'); status.classList.add('ibcalc-error');
        if (report) invalid.reportValidity();
        return;
      }
      try {
        const values = {};
        for (const name of Object.keys(math.limits)) values[name] = fields[name].valueAsNumber;
        values.currency = fields.currency.value;
        values.timing = fields.timing.value;
        result = math.calculate(values);
        formatter = new Intl.NumberFormat(locale, { style: 'currency', currency: result.inputs.currency, maximumFractionDigits: 0 });
        render(fields.mode.value);
        find('[data-results]').hidden = false;
        status.classList.remove('ibcalc-error'); status.textContent = report ? label('updated') : '';
      } catch {
        result = null; find('[data-results]').hidden = true;
        status.textContent = label('invalid'); status.classList.add('ibcalc-error');
      }
    }

    for (const input of Object.values(fields)) {
      input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => update(false), 180); });
      input.addEventListener('change', () => update(true));
      input.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); update(true); } });
    }
    find('[data-action="calculate"]').addEventListener('click', () => update(true));
    find('[data-action="reset"]').addEventListener('click', () => {
      for (const name of Object.keys(math.defaults)) fields[name].value = initial[name];
      fields.mode.value = config.type === 'all' ? 'compound' : config.type;
      update(true);
    });
    find('[data-action="download"]').addEventListener('click', () => {
      update(false);
      if (!result) return;
      const blob = new Blob(['\uFEFF' + math.toCSV(result)], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = element('a'); link.href = url; link.download = 'investment-estimate-' + fields.mode.value + '.csv';
      document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    update(false);
  }
  function discover(container) {
    if (container.nodeType !== 1 && container.nodeType !== 9) return;
    if (container.matches && container.matches('[data-ibcalc]')) initialize(container);
    for (const root of container.querySelectorAll('[data-ibcalc]')) initialize(root);
  }
  function ready() {
    discover(document);
    new MutationObserver(mutations => { for (const mutation of mutations) for (const node of mutation.addedNodes) discover(node); }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready, { once: true });
  else ready();
})();
