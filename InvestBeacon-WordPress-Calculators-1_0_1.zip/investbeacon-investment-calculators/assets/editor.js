/* Plain WordPress block-editor source. No build step. GPL-2.0-or-later. */
(function (wp) {
  'use strict';
  const h = wp.element.createElement;
  const __ = text => wp.i18n.__(text, 'investbeacon-investment-calculators');
  const attributes = {
    type: { type: 'string', default: 'all' }, initial: { type: 'number', default: 5000 }, monthly: { type: 'number', default: 250 }, years: { type: 'number', default: 20 }, rate: { type: 'number', default: 6 }, fee: { type: 'number', default: 0.2 }, inflation: { type: 'number', default: 2 }, currency: { type: 'string', default: 'EUR' }, timing: { type: 'string', default: 'end' }, credit: { type: 'boolean', default: false }
  };
  const C = wp.components;
  wp.blocks.registerBlockType('investbeacon/investment-calculator', {
    apiVersion: 3,
    title: __('Investment Calculator'),
    category: 'widgets',
    icon: 'chart-line',
    attributes,
    supports: { html: false },
    edit: function (props) {
      const a = props.attributes;
      const field = (key, label, step) => h(C.TextControl, { key, label: __(label), type: 'number', value: a[key], step: step || 0.01, min: key === 'years' ? 1 : undefined, onChange: value => { const n = Number(value); if (Number.isFinite(n)) props.setAttributes({ [key]: n }); } });
      const settings = h(wp.blockEditor.InspectorControls, {}, h(C.PanelBody, { title: __('Calculator settings'), initialOpen: true },
        h(C.SelectControl, { label: __('Calculator'), value: a.type, options: [{ label: __('All three calculators'), value: 'all' }, { label: __('Compound growth'), value: 'compound' }, { label: __('Impact of fees'), value: 'fees' }, { label: __('Purchasing power'), value: 'inflation' }], onChange: type => props.setAttributes({ type }) }),
        field('initial', 'Initial investment'), field('monthly', 'Monthly contribution'), field('years', 'Years', 1), field('rate', 'Annual gross return (%)'), field('fee', 'Annual ongoing fee (%)'), field('inflation', 'Annual inflation (%)'),
        h(C.SelectControl, { label: __('Display currency'), value: a.currency, options: ['EUR', 'GBP', 'USD', 'CHF', 'PLN', 'SEK', 'DKK', 'NOK', 'CZK', 'HUF', 'RON'].map(value => ({ value, label: value })), onChange: currency => props.setAttributes({ currency }) }),
        h(C.SelectControl, { label: __('Contribution timing'), value: a.timing, options: [{ label: __('End of each month'), value: 'end' }, { label: __('Beginning of each month'), value: 'beginning' }], onChange: timing => props.setAttributes({ timing }) }),
        h(C.ToggleControl, { label: __('Show optional InvestBeacon credit link'), checked: a.credit, help: __('Off by default. Enable only if you want a visible credit link on this page.'), onChange: credit => props.setAttributes({ credit }) })
      ));
      return h(wp.element.Fragment, {}, settings,
        h('div', wp.blockEditor.useBlockProps({ style: { background: '#f5f7fb', border: '1px solid #dee5ef', borderRadius: '16px', padding: '28px', color: '#172744' } }),
          h('p', { style: { fontSize: '12px', fontWeight: 700, letterSpacing: '1px' } }, 'INVESTBEACON'),
          h('h3', { style: { margin: '8px 0', color: '#0e1e3e' } }, __('Investment calculator')),
          h('p', {}, __('Visitors can explore compound growth, ongoing fees and purchasing power. The interactive calculator appears on the published page or Preview.')),
          h('p', {}, __('Default scenario:') + ' ' + a.currency + ' ' + a.initial + ' + ' + a.monthly + '/month · ' + a.years + ' ' + __('years') + ' · ' + a.rate + '%'),
          h('p', { style: { fontSize: '12px' } }, a.credit ? __('Optional InvestBeacon credit: enabled.') : __('No visitor-facing credit link.'))
        ));
    },
    save: function () { return null; }
  });
})(window.wp);
