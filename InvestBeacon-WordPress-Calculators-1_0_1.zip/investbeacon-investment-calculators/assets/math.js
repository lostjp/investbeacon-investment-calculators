/* InvestBeacon Investment Calculators. GPL-2.0-or-later. No runtime dependencies. */
(function (root) {
  'use strict';
  const limits = Object.freeze({ initial: [0, 100000000], monthly: [0, 1000000], years: [1, 60], rate: [-50, 50], fee: [0, 10], inflation: [-10, 30] });
  const defaults = Object.freeze({ initial: 5000, monthly: 250, years: 20, rate: 6, fee: 0.2, inflation: 2, currency: 'EUR', timing: 'end' });
  const currencies = Object.freeze(['EUR', 'GBP', 'USD', 'CHF', 'PLN', 'SEK', 'DKK', 'NOK', 'CZK', 'HUF', 'RON']);

  function validate(raw) {
    if (!raw || typeof raw !== 'object') throw new TypeError('Invalid calculator inputs.');
    const inputs = {};
    for (const [name, range] of Object.entries(limits)) {
      const value = raw[name] === undefined ? defaults[name] : raw[name];
      if (typeof value !== 'number' || !Number.isFinite(value) || value < range[0] || value > range[1]) throw new RangeError('Invalid ' + name + '.');
      inputs[name] = value;
    }
    if (!Number.isInteger(inputs.years)) throw new RangeError('Years must be a whole number.');
    inputs.currency = raw.currency === undefined ? defaults.currency : raw.currency;
    inputs.timing = raw.timing === undefined ? defaults.timing : raw.timing;
    if (!currencies.includes(inputs.currency)) throw new RangeError('Unsupported currency.');
    if (!['beginning', 'end'].includes(inputs.timing)) throw new RangeError('Invalid contribution timing.');
    return inputs;
  }

  function calculate(raw) {
    const inputs = validate(raw);
    const growth = Math.pow(1 + inputs.rate / 100, 1 / 12);
    const costRate = 1 - Math.pow(1 - inputs.fee / 100, 1 / 12);
    let balance = inputs.initial;
    let withoutFees = inputs.initial;
    let contributed = inputs.initial;
    let directFees = 0;
    const yearly = [{ year: 0, contributed, nominal: balance, real: balance, withoutFees, directFees: 0, feeImpact: 0 }];
    for (let month = 1; month <= inputs.years * 12; month++) {
      contributed += inputs.monthly;
      if (inputs.timing === 'beginning') { balance += inputs.monthly; withoutFees += inputs.monthly; }
      balance *= growth;
      withoutFees *= growth;
      const charge = balance * costRate;
      directFees += charge;
      balance -= charge;
      if (inputs.timing === 'end') { balance += inputs.monthly; withoutFees += inputs.monthly; }
      if (month % 12 === 0) {
        const year = month / 12;
        yearly.push({ year, contributed, nominal: balance, real: balance / Math.pow(1 + inputs.inflation / 100, year), withoutFees, directFees, feeImpact: Math.max(0, withoutFees - balance) });
      }
    }
    const last = yearly[yearly.length - 1];
    return { inputs, yearly, nominal: last.nominal, real: last.real, contributed, gain: balance - contributed, withoutFees, directFees, feeImpact: last.feeImpact, realAnnualRate: ((1 + inputs.rate / 100) * (1 - inputs.fee / 100) / (1 + inputs.inflation / 100) - 1) * 100 };
  }

  function toCSV(result) {
    const rows = [['Year', 'Contributed (' + result.inputs.currency + ')', 'Estimated nominal value', 'Value in today\'s money', 'Value without ongoing fees', 'Direct ongoing charges', 'Impact of fees on final value']];
    for (const row of result.yearly) rows.push([row.year, row.contributed.toFixed(2), row.nominal.toFixed(2), row.real.toFixed(2), row.withoutFees.toFixed(2), row.directFees.toFixed(2), row.feeImpact.toFixed(2)]);
    return rows.map(row => row.join(',')).join('\r\n') + '\r\n';
  }
  const api = Object.freeze({ calculate, validate, toCSV, limits, defaults, currencies });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.InvestBeaconCalculatorsMath = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
